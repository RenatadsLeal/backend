package com.example.paciente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
