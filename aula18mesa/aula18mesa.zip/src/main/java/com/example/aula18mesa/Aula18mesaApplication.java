package com.example.aula18mesa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula18mesaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula18mesaApplication.class, args);
	}

}
