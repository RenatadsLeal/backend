package com.example.aula18mesa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula18mesaApplicationTests {

	@Test
	void contextLoads() {
	}

}
