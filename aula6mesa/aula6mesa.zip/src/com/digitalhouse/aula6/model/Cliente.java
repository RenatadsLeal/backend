package com.digitalhouse.aula6.model;

public class Cliente {
}
