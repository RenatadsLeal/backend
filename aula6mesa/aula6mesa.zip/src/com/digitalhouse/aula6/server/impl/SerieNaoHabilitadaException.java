package com.digitalhouse.aula6.server.impl;

public class SerieNaoHabilitadaException extends Exception{
    public SerieNaoHabilitadaException(String mensagem) {
        super(mensagem);
    }
}
