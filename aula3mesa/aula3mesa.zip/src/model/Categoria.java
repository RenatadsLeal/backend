package model;

public enum Categoria {
    NOVATO,
    APRENDIZ,
    BOM,
    MESTRE,
    ESTAGIARIO_NOVATO,
    ESTAGIARIO_EXPERIENTE
}
