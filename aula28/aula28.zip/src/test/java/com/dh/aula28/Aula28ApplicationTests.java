package com.dh.aula28;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula28ApplicationTests {

	@Test
	void contextLoads() {
	}

}
