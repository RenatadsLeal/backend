package model;

public enum Tipo {
    CALCA,
    CAMISA
}
