package model;

public enum Tamanho {
    P,
    M,
    G
}
